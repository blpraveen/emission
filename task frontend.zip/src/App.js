import React from 'react';
import './App.css';
import React_AutoSuggest from './components/autosuggest';
function App() {
  return (
    <div className="App">
      <h1>Auto Suggest</h1>
      <React_AutoSuggest />

    </div>
  );
}

export default App;
